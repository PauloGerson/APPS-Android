package com.example.login;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_button;
    EditText txtinput,txtinput2;
    String text;

    //Intent intent = new Intent(getActivity(), MainActivity2.class);;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();


            btn_button = findViewById(R.id.button);
            txtinput = (EditText) findViewById(R.id.editTextTextPersonName);
            txtinput2 = (EditText) findViewById(R.id.editTextTextPersonName2);


        SharedPreferences preferences = getSharedPreferences("arquivo", Context.MODE_PRIVATE);

        text = preferences.getString("nome", null);

        if(text.equals("Paulo")){
            Intent intent = new Intent(getActivity(), MainActivity2.class);

            Toast.makeText(getActivity(), "Usuario cadastrado", Toast.LENGTH_SHORT).show();
            intent.putExtra("nome1", preferences.getString("nome", null));
            startActivity(intent);
            setContentView(R.layout.activity_main2);
        }

        btn_button.setOnClickListener(acaobotao());


    }
    private View.OnClickListener acaobotao(){
        return new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), MainActivity2.class);

                SharedPreferences preferences;  preferences = getSharedPreferences("arquivo", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();

                if(txtinput.getText().toString().equals("")){
                    Toast.makeText(getActivity(), "Valor no campo nome incorreto", Toast.LENGTH_SHORT).show();
                }else if(txtinput.getText().toString().equals("Paulo")){

                    editor.putString("nome", txtinput.getText().toString());
                    editor.commit();


                    intent.putExtra("nome1", preferences.getString("nome", null));
                    startActivity(intent);

                }






                //System.out.println("Teste valor" + preferences.contains("nome"));



            }

        };


    }

    public Context getActivity(){
        return this;
    }
}




